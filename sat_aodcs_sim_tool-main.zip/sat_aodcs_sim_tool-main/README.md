# Small Satellite Orbit and Attitude Simulation Tool (SSOAST)

## Capabilities

### Hardware in the Loop (HIL)

## Installation

### hard specs 

normal 
real time prerequisites

### Required Compilers

gfortran needed

python required
describe packages,
install them with requirements.txt

