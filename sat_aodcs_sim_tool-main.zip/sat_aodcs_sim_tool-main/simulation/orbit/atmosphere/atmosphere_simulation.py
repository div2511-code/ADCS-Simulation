"""
https://pypi.org/project/pyatmos/
Exponential(-0.611~1000 km), COESA76(-0.611~1000 km), NRLMSISE-00(0~2000 km), and JB2008(90~2500 km)
"""