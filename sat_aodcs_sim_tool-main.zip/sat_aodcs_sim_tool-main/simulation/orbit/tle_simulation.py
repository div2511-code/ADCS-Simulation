"""
https://pypi.org/project/sgp4/

"""
import os
from datetime import datetime
from logging import raiseExceptions
from typing import List
from sgp4.api import Satrec, jday, SGP4_ERRORS, WGS72OLD, WGS72, WGS84

#time_now = datetime.utcnow()
#desired_satellite_ID = "FORESAIL-1"
filename = "current_tles.txt"
filelocation = "TLEs"
filepath = os.path.join("simulation", "orbit", filelocation, filename)

def get_sat_tle_from_file(desired_satellite_ID: str = "FORESAIL-1") -> Satrec:

    tle = {1: None, 2: None}
    
    # using tle file
    with open(filepath) as tlefile:
        for line in tlefile:
            if (line.strip() == desired_satellite_ID):
                # first line tle
                line = tlefile.readline()
                if line[:1] == "1":
                    tle[1] = line.strip()
                # second line tle
                line = tlefile.readline()
                if line[:1] == "2":
                    tle[2] = line.strip()
    print(tle)
    satellite_rec = Satrec.twoline2rv(tle[1], tle[2])

    return satellite_rec

def set_sat_tle(
    gravity_model: int, # gravity model
    sgp4_mode: str,     # 'a' = old AFSPC mode, 'i' = improved mode
    satnum: int,        # satnum: Satellite number
    epoch: float,       # epoch: days since 1949 December 31 00:00 UT
    bstar: float,       # bstar: drag coefficient (1/earth radii)
    ndot: float,        # ndot: ballistic coefficient (revs/day)
    nddot: float,       # nddot: mean motion 2nd derivative (revs/day^3)
    ecco: float,        # ecco: eccentricity
    argpo: float,       # argpo: argument of perigee (radians)
    inclo: float,       # inclo: inclination (radians)
    mo: float,          # mo: mean anomaly (radians)
    no_kozai: float,    # no_kozai: mean motion (radians/minute)
    nodeo: float        # nodeo: R.A. of ascending node (radians)
    ) -> Satrec:

    satellite_rec = Satrec()

    satellite_rec.sgp4init(
        gravity_model,      # gravity model
        sgp4_mode,          # 'a' = old AFSPC mode, 'i' = improved mode
        satnum,             # satnum: Satellite number
        epoch,              # epoch: days since 1949 December 31 00:00 UT
        bstar,              # bstar: drag coefficient (1/earth radii)
        ndot,               # ndot: ballistic coefficient (revs/day)
        nddot,              # nddot: mean motion 2nd derivative (revs/day^3)
        ecco,               # ecco: eccentricity
        argpo,              # argpo: argument of perigee (radians)
        inclo,              # inclo: inclination (radians)
        mo,                 # mo: mean anomaly (radians)
        no_kozai,           # no_kozai: mean motion (radians/minute)
        nodeo,              # nodeo: R.A. of ascending node (radians)
    )

    return satellite_rec

def get_sat_position(
    time_now: datetime, 
    satellite: Satrec) -> List:
    
    julian_day, day_fraction = jday(year=time_now.year, mon=time_now.month, day=time_now.day, hr=time_now.hour, 
                    minute=time_now.minute, sec=time_now.second)
    print(julian_day, day_fraction)

    # True Equator Mean Equinox position (km)
    # True Equator Mean Equinox velocity (km/s)
    compute_error, position, velocity = satellite.sgp4(julian_day, day_fraction)

    if compute_error != 0:
        error_code = SGP4_ERRORS[compute_error]
        raise RuntimeError(error_code)
    print(position, velocity)

    return position, velocity
    