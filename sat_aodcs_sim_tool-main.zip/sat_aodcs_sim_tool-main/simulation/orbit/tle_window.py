# system
import json

# QT
from cProfile import label
from PySide2.QtCore import QSize
from PySide2.QtWidgets import (
    QPushButton, QLabel, QLineEdit, 
    QVBoxLayout, QWidget, QRadioButton, 
    QDoubleSpinBox, QGroupBox, QHBoxLayout
    )
from prompt_toolkit import PromptSession

# sgp4
from sgp4 import exporter
from sgp4.api import WGS72OLD, WGS72, WGS84

# our sgp4
from .tle_simulation import get_sat_tle_from_file, set_sat_tle
from satellite import sim_satellite

# TLE and orbit parameter custimzer window
class TLEWindow(QWidget):
    def __init__(self):
        super().__init__()

        #self.setMinimumSize(QSize(400, 300))
        self.setWindowTitle("SSOAST - TLE and Orbit Parameters")

        # buttons to close and or save
        self.close_button = QPushButton("Close without saving")
        self.save_close_button = QPushButton("Save Parameters and Close")
        self.save_button = QPushButton("Save Parameters")
        
        # set checkable
        self.close_button.setCheckable(True)
        self.save_close_button.setCheckable(True)
        self.save_button.setCheckable(True)

        # diable buttons as long as there is no new data that has to be saved
        self.save_close_button.setEnabled(False)
        self.save_button.setEnabled(False)

        self.buttons = [
            self.close_button,
            self.save_close_button,
            self.save_button
        ]

        # data names
        names = [
            "Gravity Model",                                    # (WGS72OLD, WGS72, WGS84)
            "SGP4 Mode",                                        # 'a' = old AFSPC mode, 'i' = improved mode
            "Satellite Number",                                 # satnum: Satellite number
            "Epoch [days since 1949 December 31 00:00 UT]",     # epoch: days since 1949 December 31 00:00 UT
            "B* [1/earth radii]",                               # bstar: drag coefficient (1/earth radii)
            "Ballistic Coefficient, ndot [revs/day]",           # ndot: ballistic coefficient (revs/day)
            "Mean Motion 2nd derivative, nddot [revs/day^3]",   # nddot: mean motion 2nd derivative (revs/day^3)
            "Eccentricity",                                     # ecco: eccentricity
            "Argument of perigee [radians]",                    # argpo: argument of perigee (radians)
            "Inclination [radians]",                            # inclo: inclination (radians)
            "Mean Anomaly [radians]",                           # mo: mean anomaly (radians)
            "Mean Motion [radians/minute]",                     # no_kozai: mean motion (radians/minute)
            "R.A. of ascending node [radians]",                 # nodeo: R.A. of ascending node (radians)
        ]

        self.satellite_name = QLineEdit()
        self.satellite_name.setText("FORESAIL-1")
        self.load_from_file = QPushButton("Load TLE from File")
        self.load_from_file.clicked.connect(self.load_tle_from_file)
        self.lineinputs = [
            self.satellite_name,
            self.load_from_file,

        ]

        self.inputs = [
        ]

        for item in names:
            if item == "Gravity Model":
                grav_layout = QVBoxLayout()
                buttongroup_grav = QGroupBox(item)

                self.button_WGS72OLD = QRadioButton("WGS72OLD")
                self.button_WGS72 = QRadioButton("WGS72")
                self.button_WGS84 = QRadioButton("WGS84")

                self.button_WGS72.setChecked(True)

                grav_layout.addWidget(self.button_WGS72OLD)
                grav_layout.addWidget(self.button_WGS72)
                grav_layout.addWidget(self.button_WGS84)
                buttongroup_grav.setLayout(grav_layout)

                self.lineinputs.append(buttongroup_grav)

            elif item == "SGP4 Mode":
                sgp4_layout = QVBoxLayout()
                buttongroup_sgp4 = QGroupBox(item)
                
                self.sgp4_old = QRadioButton("old AFSPC")
                self.sgp4_improved = QRadioButton("improved")
                
                self.sgp4_improved.setChecked(True)
                
                sgp4_layout.addWidget(self.sgp4_old)
                sgp4_layout.addWidget(self.sgp4_improved)

                buttongroup_sgp4.setLayout(sgp4_layout)
                self.lineinputs.append(buttongroup_sgp4)

            else:
                self.lineinputs.append(QLabel(item))

                value_input = QDoubleSpinBox()
                value_input.setDecimals(10)
                value_input.setMaximum(10000000)
                value_input.textChanged.connect(self.enable_save_buttons)
                
                self.lineinputs.append(value_input)
                self.inputs.append(value_input)
        
        #for item in self.inputs:
        #    item.valueChanged.connect(self.enable_save_buttons())

        # old saved values
        self.old_values = [
        ]
        
        for _ in range(21):
            data_label = QLabel("")
            data_value = QLabel("")
            self.old_values.append(data_label)
            self.old_values.append(data_value)

        if sim_satellite.orbit_parameters != None:
            self.reload_display_output()

        vlayout_left = QVBoxLayout()
        vlayout_right = QVBoxLayout()
        hlayout = QHBoxLayout()

        for item in self.lineinputs:
            vlayout_left.addWidget(item)
        for item in self.old_values:
            vlayout_right.addWidget(item)
        for item in self.buttons:
            vlayout_left.addWidget(item)
        
        hlayout.addLayout(vlayout_left)
        hlayout.addLayout(vlayout_right)

        try:
            self.load_tle_from_file()
        except:
            pass

        self.setLayout(hlayout)
    
    #def load(self):
    #    try:
    #        with open('.tle_data.json', 'r') as f:
    #            self.model.todos = json.load(f)
    #    except Exception:
    #        pass

    #def save(self, fields):
    #    with open('.tle_data.json', 'w') as f:
    #        data = json.dump(self.model.todos, f)
    
    def save_data(self):
        gavity_model = None
        if self.button_WGS72.isChecked():
            gavity_model = WGS72
        elif self.button_WGS72OLD.isChecked():
            gavity_model = WGS72OLD
        elif self.button_WGS84.isChecked():
            gavity_model = WGS84
        
        # 'a' = old AFSPC mode, 'i' = improved mode
        sgp4_mode = None
        if self.sgp4_old.isChecked():
            sgp4_mode = 'a'
        elif self.sgp4_improved.isChecked():
            sgp4_mode = 'i'

        values = []
        for item in self.inputs:
            values.append(item.value())

        sim_satellite.orbit_parameters = set_sat_tle(gravity_model=gavity_model, sgp4_mode=sgp4_mode, )
        self.reload_display_output()
    
    def load_tle_from_file(self):
        sim_satellite.orbit_parameters = get_sat_tle_from_file(self.satellite_name.text())
        self.reload_display_output()

    def reload_display_output(self):
        fields = exporter.export_omm(sim_satellite.orbit_parameters, self.satellite_name.text())
        keys = list(fields.keys())
        values = list(fields.values())
        i = 0
        j = 0
        while i < len(self.old_values):
            self.old_values[i].setText(str(keys[j]))
            self.old_values[i+1].setText(str(values[j]))
            j += 1
            i += 2
        
    def enable_save_buttons(self):
        self.save_close_button.setEnabled(True)
        self.save_button.setEnabled(True)
    