"""
IGRF    https://pypi.org/project/igrf/
A Fortran compiler is required, such as gfortran:

    Linux: apt install gfortran
    Mac: brew install gcc
    gfortran for Windows (MinGW) https://www.scivision.dev/windows-gcc-gfortran-cmake-make-install/


"""

import igrf
from datetime import datetime
import xarray

def get_mag_field(timestamp: datetime, latitude: float, longitude: float, altitude: int) -> xarray:
    """
    Get magnetic field in ECEF frame,

    altitude mustbe positive
    returns:
        xarray

    e.g.:
        Dimensions:  (alt_km: 1)
        Coordinates:
        * alt_km   (alt_km) int64 100
        Data variables:
            north    (alt_km) float64 1.156e+04
            east     (alt_km) float64 3.289e+03
            down     (alt_km) float64 5.248e+04
            total    (alt_km) float64 5.384e+04
            incl     (alt_km) float64 77.1
            decl     (alt_km) float64 15.89
        Attributes:
            time:     2022-04-25 06:16:12.602408
            isv:      0
            itype:    1
            glat:     65
            glon:     -148
    """
    #today = datetime.utcnow()
    mag = igrf.igrf(time=timestamp, glat=latitude, glon=longitude, alt_km=altitude)

    #print(mag)
    return mag

mag = get_mag_field(datetime.utcnow(), 55, 44, 5000)

print(mag.alt_km)