"""
"""
# system and general libs
import sys  # Only needed for access to command line arguments
from datetime import datetime

# QT
from PySide2.QtCore import QSize
from PySide2.QtWidgets import QApplication, QMainWindow, QPushButton, QLabel, QLineEdit, QVBoxLayout, QWidget

# simulation modules
from satellite import sim_satellite
from simulation.orbit.tle_window import TLEWindow

# application's main window
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.tle_window = None

        self.setup_window()
        self.setup_open_tle_button()

    def setup_window(self):
        self.setMinimumSize(QSize(400, 300))
        self.setWindowTitle("SSOAST - Small Satellite Orbit and Attitude Simulation Tool")

    def setup_open_tle_button(self):
        self.set_tle_button = QPushButton("Set Orbital Parameters")
        #start_sim_button = QPushButton("Start Simulation")
        #start_HIL_sim_button = QPushButton("Start HIL Simulation")

        #start_sim_button.setCheckable(True)
        self.set_tle_button.setCheckable(True)
        #start_sim_button.clicked.connect(self.execute_simulation)
        self.set_tle_button.clicked.connect(self.open_tle_window)

        self.label = QLabel()

        self.input = QLineEdit()
        self.input.textChanged.connect(self.label.setText)

        layout = QVBoxLayout()
        layout.addWidget(self.input)
        layout.addWidget(self.label)
        layout.addWidget(self.set_tle_button)

        container = QWidget()
        container.setLayout(layout)


        # Set the central widget of the Window.
        self.setCentralWidget(container)
    
    def open_tle_window(self, checked):
        #self.set_tle_button.setText("You already clicked me.")
        #self.set_tle_button.setEnabled(False)
        if self.tle_window is None:
            self.tle_window = TLEWindow()
        self.tle_window.show()

    def execute_simulation(self):
        now = datetime.utcnow()
        #get_sat_orbital_parameters(now)

    def the_button_was_toggled(self, checked):
        print("Checked?", checked)

    def execute_HIL_simulation(self):
        print("Clicked!")


if __name__ == '__main__':
    # You need one (and only one) QApplication instance per application.
    # Pass in sys.argv to allow command line arguments for your app.
    # If you know you won't use command line arguments QApplication([]) works too.
    app = QApplication(sys.argv)

    # Create a Qt widget, which will be our window.
    window = MainWindow()
    window.show()  # IMPORTANT!!!!! Windows are hidden by default.

    # Start the event loop.
    app.exec_()


    # Your application won't reach here until you exit and the event
    # loop has stopped.
