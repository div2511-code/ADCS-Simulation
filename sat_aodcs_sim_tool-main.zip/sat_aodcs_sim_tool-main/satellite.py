"""
Main class that holds every piece of data at a given time 
for the simulated satellite
"""

class satellite():

    def __init__(self):
        self.orbit_parameters = None    #sgp4 sat record


# global for the satellite under simulation
sim_satellite = satellite()